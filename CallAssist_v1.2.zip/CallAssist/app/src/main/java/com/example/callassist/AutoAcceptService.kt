package com.example.callassist

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.example.callassist.OfferParser.Line
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 속도: ① 접근성 노드에서 먼저 읽기(OCR 없음) ② 안 되면 화면 아래쪽만 잘라 축소 후 OCR, 인식기 재사용, 처리 중 프레임 폐기
 * 클릭: ① 노드 ACTION_CLICK ② 안 되면 좌표 제스처(자르기·축소 역변환)
 * 떠 있는 카드: 우버 콜 카드가 다른 앱(카톡 등) 위에 팝업으로 뜨는 경우가 있어
 *   '맨 앞 앱이 우버인가'가 아니라 '우버 창 중 버튼 위치를 덮는 다른 창이 없는가'로 확인합니다.
 * 1.2: 탭/클릭을 보낸 뒤 3.6초 동안 '콜 수락' 버튼이 사라지는지 확인해 기록합니다(우버가 입력을 받았는지 판단용).
 *      감시 주기 600→380ms, OCR 간격 450→380ms.
 */
class AutoAcceptService : AccessibilityService() {

    companion object {
        const val TARGET = "com.ubercab.driver"
        @Volatile var instance: AutoAcceptService? = null
        private const val MIN_GAP_MS = 100L
        private const val OCR_GAP_MS = 380L        // 시스템 스크린샷 최소 간격(약 333ms)보다 약간 크게 (1.1: 450)
        private const val POLL_MS = 380L           // 1.1: 600
        private const val MAX_W = 720f
        private const val MAX_FRAME_AGE_MS = 1500L
        /** 탭 후 '콜 수락' 버튼을 다시 보는 시각(탭 요청 후 ms). 스크린샷 최소 간격보다 넓게 띄웁니다. */
        private val VERIFY_AT = longArrayOf(350L, 750L, 1300L, 2100L, 3600L)
        /** 탭 위치와 버튼 위치가 이 픽셀 안이면 '버튼 위를 눌렀다'고 봅니다. */
        private const val NEAR_PX = 60
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val recognizer by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val busy = AtomicBoolean(false)
    @Volatile private var pending = false
    private var lastRun = 0L
    private var lastOcr = 0L
    private var lastRejectNote = ""

    private val poll = object : Runnable {
        override fun run() {
            if (Store.armed) analyze()
            main.postDelayed(this, POLL_MS)
        }
    }

    override fun onServiceConnected() {
        Store.init(this)
        instance = this
        Store.armed = false
        Store.log("서비스 연결됨 · v1.2 (탭 후 확인 켜짐)")
        recognizer // 미리 생성(첫 인식 지연 방지)
        main.postDelayed(poll, POLL_MS)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null; main.removeCallbacksAndMessages(null); Store.armed = false
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (Store.armed) analyze()
    }

    private val screenW get() = resources.displayMetrics.widthPixels
    private fun kw() = Store.keywords.split(",")

    // ------------------------------------------------------------------ 분석
    private fun analyze() {
        if (!Store.armed) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastRun < MIN_GAP_MS) { pending = true; return }
        if (!busy.compareAndSet(false, true)) { pending = true; return }
        lastRun = now; pending = false
        try {
            if (!nativePath(now)) ocrPath(now) else finish()
        } catch (t: Throwable) {
            Store.log("오류(분석): ${t.javaClass.simpleName}"); finish()
        }
    }

    private fun finish() {
        busy.set(false)
        if (pending && Store.armed) main.postDelayed({ analyze() }, MIN_GAP_MS)
    }

    /** 같은 거절 사유가 반복 기록되지 않게 */
    private fun noteReject(r: OfferParser.Result) {
        val key = "${r.tripMinutes}|${r.destination}|${r.reason}"
        if (key != lastRejectNote) { lastRejectNote = key; Store.log("통과 안 함: ${r.reason}${r.tripMinutes?.let { " (${it}분)" } ?: ""}") }
    }

    // ------------------------------------------------------------ 창 확인
    private fun uberWindows(): List<AccessibilityWindowInfo> =
        windows.filter { it.root?.packageName?.toString() == TARGET }

    /** (x,y)에 탭하면 우버 창이 받는지: 우버 창 안이고, 그 위에 덮는 다른 앱 창이 없어야 함 */
    private fun uberOwnsPoint(x: Int, y: Int): Boolean {
        val all = windows
        val r = Rect()
        val uber = all.filter { it.root?.packageName?.toString() == TARGET }
            .filter { it.getBoundsInScreen(r); r.contains(x, y) }
            .maxByOrNull { it.layer } ?: return false
        return all.none { w ->
            w.layer > uber.layer && w.type != AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY &&
                w.root?.packageName?.toString() != TARGET &&
                run { w.getBoundsInScreen(r); r.contains(x, y) }
        }
    }

    // ------------------------------------------------------------ 1) 노드 경로
    private class NodeLine(val line: Line, val node: AccessibilityNodeInfo)

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<NodeLine>, depth: Int = 0) {
        if (n == null || depth > 45 || !n.isVisibleToUser) return
        val t = (n.text ?: n.contentDescription)?.toString()?.trim()
        if (!t.isNullOrEmpty()) {
            val r = Rect(); n.getBoundsInScreen(r)
            out.add(NodeLine(Line(t, r.left, r.top, r.right, r.bottom), n))
        }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    /** @return true = 노드로 판단 완료, false = OCR 필요 */
    private fun nativePath(t0: Long): Boolean {
        val wins = uberWindows()
        if (wins.isEmpty()) return true                       // 우버 창 자체가 없으면 OCR도 하지 않음
        val nodes = ArrayList<NodeLine>()
        wins.forEach { collect(it.root, nodes) }
        if (nodes.none { OfferParser.isAcceptLabel(it.line.text) }) return false
        val res = OfferParser.evaluate(nodes.map { it.line }, screenW, Store.minMinutes, kw())
        if (res.tripMinutes == null) return false             // 카드 글자를 노드로 못 읽음 → OCR
        val ms = SystemClock.elapsedRealtime() - t0
        if (!res.accept) { noteReject(res); return true }
        val btn = nodes.first { it.line === res.button }
        Store.armed = false
        if (clickNode(btn.node)) {
            Store.log("노드 클릭 | ${res.reason} | 분석 ${ms}ms")
            verifyAfterTap(btn.line.cx.toInt(), btn.line.cy.toInt(), SystemClock.elapsedRealtime())
        } else {
            tap(btn.line.cx, btn.line.cy, "노드→제스처", res.reason, ms)
        }
        return true
    }

    private fun clickNode(start: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = start
        repeat(4) {
            val n = cur ?: return false
            if (n.isClickable && n.isEnabled) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = n.parent
        }
        return false
    }

    // ------------------------------------------------------------- 2) OCR 경로
    private fun ocrPath(t0: Long) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastOcr < OCR_GAP_MS) { pending = true; finish(); return }
        lastOcr = now
        takeScreenshot(Display.DEFAULT_DISPLAY, worker, object : TakeScreenshotCallback {
            override fun onSuccess(shot: ScreenshotResult) {
                try {
                    val hw = shot.hardwareBuffer
                    val hwBmp = Bitmap.wrapHardwareBuffer(hw, shot.colorSpace)
                    if (hwBmp == null) { hw.close(); finish(); return }
                    val W = hwBmp.width; val H = hwBmp.height
                    val top = H * Store.roiTopPct / 100
                    val scale = minOf(1f, MAX_W / W)
                    val dw = (W * scale).toInt().coerceAtLeast(1)
                    val dh = ((H - top) * scale).toInt().coerceAtLeast(1)
                    // 하드웨어 비트맵 → 잘라서 축소한 소프트 비트맵 (전체 복사 없이 한 번에)
                    val soft = hwBmp.copy(Bitmap.Config.ARGB_8888, false)
                    hwBmp.recycle(); hw.close()
                    val small = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888)
                    Canvas(small).drawBitmap(soft, Rect(0, top, W, H), Rect(0, 0, dw, dh), Paint(Paint.FILTER_BITMAP_FLAG))
                    soft.recycle()
                    val shotMs = SystemClock.elapsedRealtime() - t0
                    recognizer.process(InputImage.fromBitmap(small, 0))
                        .addOnSuccessListener(worker) { text ->
                            small.recycle()
                            try { onOcr(text, scale, top, W, t0, shotMs) } finally { finish() }
                        }
                        .addOnFailureListener(worker) { small.recycle(); Store.log("OCR 실패"); finish() }
                } catch (t: Throwable) {
                    Store.log("오류(캡처): ${t.javaClass.simpleName}"); finish()
                }
            }
            override fun onFailure(code: Int) {
                if (code != AccessibilityService.ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) Store.log("캡처 오류 코드=$code")
                else pending = true
                finish()
            }
        })
    }

    private fun onOcr(text: com.google.mlkit.vision.text.Text, scale: Float, top: Int, fullW: Int, t0: Long, shotMs: Long) {
        if (!Store.armed) return
        // OCR 좌표 → 실제 화면 좌표로 되돌림
        val lines = text.textBlocks.flatMap { it.lines }.mapNotNull { l ->
            l.boundingBox?.let { b ->
                Line(l.text, (b.left / scale).toInt(), (b.top / scale).toInt() + top,
                    (b.right / scale).toInt(), (b.bottom / scale).toInt() + top)
            }
        }
        val res = OfferParser.evaluate(lines, fullW, Store.minMinutes, kw())
        if (res.button == null) return
        if (!res.accept) { noteReject(res); return }
        val total = SystemClock.elapsedRealtime() - t0
        if (total > MAX_FRAME_AGE_MS) { Store.log("화면이 오래되어 탭 취소(${total}ms)"); return }
        val b = res.button
        main.post {
            if (!Store.armed) return@post
            Store.armed = false
            tap(b.cx, b.cy, "OCR(캡처 ${shotMs}ms)", res.reason, total)
        }
    }

    // --------------------------------------------------------------- 제스처
    private fun tap(x: Float, y: Float, via: String, reason: String, analyzeMs: Long) {
        if (!uberOwnsPoint(x.toInt(), y.toInt())) {
            Store.log("$via | 탭 취소: 버튼 위치에 우버 창이 없거나 다른 창이 덮고 있음 (${x.toInt()},${y.toInt()})")
            return
        }
        val press = Store.pressMs
        val sentAt = SystemClock.elapsedRealtime()
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(Path().apply { moveTo(x, y) }, 0, press)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                Store.log("$via | $reason | 분석 ${analyzeMs}ms | (${x.toInt()},${y.toInt()}) ${press}ms | 응답=완료 +${SystemClock.elapsedRealtime() - sentAt}ms")
            }
            override fun onCancelled(d: GestureDescription?) {
                Store.log("$via | (${x.toInt()},${y.toInt()}) | 응답=취소됨(다른 터치/화면 변경)")
            }
        }, main)
        if (!ok) {
            Store.log("$via | 제스처 요청 거절됨(접근성 권한 확인)")
        } else {
            verifyAfterTap(x.toInt(), y.toInt(), sentAt)
        }
    }

    // ------------------------------------------------------ 탭 후 확인 (1.2)
    /** 한 번 살펴본 결과. ok=false 는 캡처/OCR 실패(판단 불가). note 가 있고 present=false 면 우버 창 자체가 없는 경우. */
    private class Seen(val ok: Boolean, val present: Boolean, val cx: Float = 0f, val cy: Float = 0f, val note: String = "")

    /** 탭 1회에 대한 확인 진행 상태 */
    private class Verify(val x: Int, val y: Int, val sentAt: Long) {
        val trail = StringBuilder()
        var firstGone = -1L                      // 버튼이 연속으로 안 보이기 시작한 시각(탭 후 ms). 다시 보이면 -1
        fun add(at: Long, what: String) {
            if (trail.isNotEmpty()) trail.append(" · ")
            trail.append(at).append("ms ").append(what)
        }
    }

    private fun verifyAfterTap(x: Int, y: Int, sentAt: Long) {
        verifyStep(Verify(x, y, sentAt), 0)
    }

    /**
     * 탭 후 VERIFY_AT 시각마다 '콜 수락' 버튼이 아직 보이는지 확인해, 끝나면 기록에 한 줄을 남깁니다.
     * OCR 한 번 오독으로 '사라짐'이 잘못 나오지 않도록, 두 번 연속 안 보여야 사라진 것으로 봅니다(마지막 확인 제외).
     */
    private fun verifyStep(v: Verify, idx: Int) {
        val wait = (v.sentAt + VERIFY_AT[idx] - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
        main.postDelayed({
            look { s ->
                val at = SystemClock.elapsedRealtime() - v.sentAt
                val last = idx == VERIFY_AT.size - 1
                if (s.ok && !s.present && s.note.isNotEmpty()) {
                    // 우버 창 자체가 사라짐(다른 앱으로 이동 등)
                    v.add(at, s.note)
                    Store.log("확인 | ${s.note} [${v.trail}]")
                } else if (s.ok && !s.present) {
                    v.add(at, "없음")
                    val twice = v.firstGone >= 0
                    if (!twice) v.firstGone = at
                    if (twice || last) {
                        Store.log("확인 | 탭 후 ${v.firstGone}ms부터 수락 버튼이 안 보임 [${v.trail}] → 손을 안 댔을 때만 '우버가 탭을 받음'으로 볼 수 있음(직접 눌렀거나 콜 만료·타인 배정이면 아님)")
                    } else {
                        verifyStep(v, idx + 1)
                    }
                } else {
                    v.firstGone = -1L
                    v.add(at, if (s.ok) "있음" else "판독 실패")
                    if (!last) {
                        verifyStep(v, idx + 1)
                    } else if (!s.ok) {
                        Store.log("확인 | 판독 실패 [${v.trail}] ${s.note}")
                    } else {
                        val dx = (s.cx - v.x).toInt()
                        val dy = (s.cy - v.y).toInt()
                        val far = kotlin.math.abs(dx) > NEAR_PX || kotlin.math.abs(dy) > NEAR_PX
                        val verdict = if (far) "버튼 위치가 달라 탭이 빗나갔을 수 있음"
                                      else "버튼 위를 눌렀는데 반응 없음(우버가 입력을 무시했을 가능성)"
                        Store.log("확인 | 탭 후 ${at}ms에도 수락 버튼 그대로 [${v.trail}] 탭(${v.x},${v.y}) 버튼(${s.cx.toInt()},${s.cy.toInt()}) 차이(${dx},${dy})px → $verdict")
                    }
                }
            }
        }, wait)
    }

    /** 지금 화면에 '콜 수락' 버튼이 있는지 본다. 노드에 있으면 그대로, 없으면 OCR로 확인(카드가 노드에 안 잡히는 경우가 있어서). */
    private fun look(cb: (Seen) -> Unit) {
        var found: Seen? = null
        try {
            val wins = uberWindows()
            if (wins.isEmpty()) {
                found = Seen(true, false, note = "우버 창 없음")
            } else {
                val nodes = ArrayList<NodeLine>()
                wins.forEach { collect(it.root, nodes) }
                val hit = nodes.filter { OfferParser.isAcceptLabel(it.line.text) }.maxByOrNull { it.line.bottom }
                if (hit != null) found = Seen(true, true, hit.line.cx, hit.line.cy)
            }
        } catch (t: Throwable) {
            found = Seen(false, false, note = "노드 오류 ${t.javaClass.simpleName}")
        }
        val s = found
        if (s != null) cb(s) else lookOcr(cb)
    }

    /** 화면을 캡처해 OCR로 '콜 수락' 글자가 보이는지 확인(ocrPath 와 같은 방식, 탭 판단과는 무관한 확인 전용). */
    private fun lookOcr(cb: (Seen) -> Unit) {
        lastOcr = SystemClock.elapsedRealtime()
        takeScreenshot(Display.DEFAULT_DISPLAY, worker, object : TakeScreenshotCallback {
            override fun onSuccess(shot: ScreenshotResult) {
                var early: Seen? = null
                try {
                    val hw = shot.hardwareBuffer
                    val hwBmp = Bitmap.wrapHardwareBuffer(hw, shot.colorSpace)
                    if (hwBmp == null) {
                        hw.close()
                        early = Seen(false, false, note = "캡처 변환 실패")
                    } else {
                        val W = hwBmp.width; val H = hwBmp.height
                        val top = H * Store.roiTopPct / 100
                        val scale = minOf(1f, MAX_W / W)
                        val dw = (W * scale).toInt().coerceAtLeast(1)
                        val dh = ((H - top) * scale).toInt().coerceAtLeast(1)
                        val soft = hwBmp.copy(Bitmap.Config.ARGB_8888, false)
                        hwBmp.recycle(); hw.close()
                        val small = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888)
                        Canvas(small).drawBitmap(soft, Rect(0, top, W, H), Rect(0, 0, dw, dh), Paint(Paint.FILTER_BITMAP_FLAG))
                        soft.recycle()
                        recognizer.process(InputImage.fromBitmap(small, 0))
                            .addOnSuccessListener(worker) { text ->
                                small.recycle()
                                val lines = text.textBlocks.flatMap { it.lines }.mapNotNull { l ->
                                    l.boundingBox?.let { b ->
                                        Line(l.text, (b.left / scale).toInt(), (b.top / scale).toInt() + top,
                                            (b.right / scale).toInt(), (b.bottom / scale).toInt() + top)
                                    }
                                }
                                val btn = lines.filter { OfferParser.isAcceptLabel(it.text) }.maxByOrNull { it.bottom }
                                cb(if (btn != null) Seen(true, true, btn.cx, btn.cy) else Seen(true, false))
                            }
                            .addOnFailureListener(worker) { small.recycle(); cb(Seen(false, false, note = "OCR 실패")) }
                    }
                } catch (t: Throwable) {
                    early = Seen(false, false, note = "캡처 오류 ${t.javaClass.simpleName}")
                }
                val e = early
                if (e != null) cb(e)
            }
            override fun onFailure(code: Int) {
                cb(Seen(false, false, note = "캡처 오류 코드=$code"))
            }
        })
    }
}
