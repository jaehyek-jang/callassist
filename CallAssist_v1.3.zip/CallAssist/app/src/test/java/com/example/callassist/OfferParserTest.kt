package com.example.callassist

import com.example.callassist.OfferParser.Line
import org.junit.Assert.*
import org.junit.Test

/** 좌표는 실제 스크린샷(1080x2340)에서 옮긴 값 */
class OfferParserTest {
    private val kw = listOf("인천", "공항", "운서", "영종", "터미널")
    private val W = 1080
    private fun L(t: String, l: Int, top: Int, r: Int, b: Int) = Line(t, l, top, r, b)

    private fun card(trip: String, pickup: List<String>, dir: String, dest: List<String>, mapIcon: Boolean = false): List<Line> {
        val out = mutableListOf(
            L("가맹 전용 콜", 255, 1030, 490, 1085),
            L("동대문구", 815, 160, 960, 200),            // 지도 라벨
            L("인천", 1035, 1200, 1080, 1240),             // 화면 가장자리 지도 라벨(무시돼야 함)
            L(trip, 96, 1150, 610, 1260),
            L("11분(2.1km) 남음", 120, 1325, 470, 1380),
        )
        var y = 1500
        pickup.forEach { out += L(it, 205, y, 900, y + 60); y += 90 }
        out += L(dir, 205, y, 360, y + 60); y += 90
        dest.forEach { out += L(it, 205, y, 900, y + 60); y += 90 }
        out += L("콜 수락", if (mapIcon) 570 else 475, 2000, if (mapIcon) 705 else 605, 2055)
        out += L("청계", 425, 2215, 495, 2255)              // 카드 아래 지도 라벨
        return out
    }

    @Test fun shortTripRejected() {
        val r = OfferParser.evaluate(card("39분 운행", listOf("종로구 화동 삼청로"), "남동쪽", listOf("서울특별시 강남구", "언주로164길")), W, 40, kw)
        assertFalse(r.accept); assertEquals(39, r.tripMinutes)
    }

    @Test fun longTripToAirportAccepted() {
        val r = OfferParser.evaluate(card("52분 운행", listOf("중구 북창동 남대문로"), "서쪽", listOf("인천광역시 중구 공항로 272", "인천국제공항 제1여객터미널")), W, 40, kw)
        assertTrue(r.reason, r.accept); assertEquals(52, r.tripMinutes)
        assertEquals("콜 수락", r.button!!.text)
    }

    @Test fun hourFormat() {
        val r = OfferParser.evaluate(card("1시간 운행", listOf("A"), "남서쪽", listOf("인천광역시 중구 영종해안남로")), W, 40, kw)
        assertTrue(r.accept); assertEquals(60, r.tripMinutes)
    }

    @Test fun pickupKeywordDoesNotCount() {
        val r = OfferParser.evaluate(card("55분 운행", listOf("인천공항 제2터미널"), "북동쪽", listOf("서울특별시 중구 삼일대로10길")), W, 40, kw)
        assertFalse(r.accept)
    }

    @Test fun mapLabelsIgnored() {
        // 가장자리 '인천' 라벨이 있어도 목적지가 서울이면 거절
        val r = OfferParser.evaluate(card("45분 운행", listOf("종로구"), "동쪽", listOf("서울특별시")), W, 40, kw)
        assertFalse(r.accept); assertEquals("목적지 키워드 없음", r.reason)
    }

    @Test fun mapIconLayout() {
        val r = OfferParser.evaluate(card("41분 운행", listOf("남대문로4가"), "북동쪽", listOf("인천 연수구"), mapIcon = true), W, 40, kw)
        assertTrue(r.accept)
    }

    @Test fun splitTripText() {
        val lines = card("41분", listOf("A"), "동쪽", listOf("영종도")) + L("운행", 380, 1160, 600, 1255)
        assertTrue(OfferParser.evaluate(lines, W, 40, kw).accept)
    }

    @Test fun noDirectionIsSafeReject() {
        val lines = card("50분 운행", listOf("A"), "모름", listOf("인천"))
        assertFalse(OfferParser.evaluate(lines, W, 40, kw).accept)
    }

    @Test fun labels() {
        assertTrue(OfferParser.isAcceptLabel("콜 수락")); assertTrue(OfferParser.isAcceptLabel("콜수락"))
        assertFalse(OfferParser.isAcceptLabel("콜수락 위치 확인 부탁드립니다"))
        assertNull(OfferParser.minutesIn("운행 리스트"))
    }
}
