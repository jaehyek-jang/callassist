package com.example.callassist

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 설정(영구)과 실행 상태/기록(메모리). armed 는 항상 꺼진 상태로 시작합니다. */
object Store {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) {
        if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    }

    @Volatile var armed = false

    var minMinutes: Int
        get() = sp.getInt("min", 40)
        set(v) = sp.edit().putInt("min", v).apply()
    var keywords: String
        get() = sp.getString("kw", "인천,공항,운서,영종,터미널") ?: ""
        set(v) = sp.edit().putString("kw", v).apply()
    /** OCR 대상 영역: 화면 위쪽 N% 는 잘라냅니다(팝업이 아래쪽에 뜨는 경우). */
    var roiTopPct: Int
        get() = sp.getInt("roi", 20)
        set(v) = sp.edit().putInt("roi", v.coerceIn(0, 80)).apply()
    var pressMs: Long
        get() = sp.getLong("press", 60L)
        set(v) = sp.edit().putLong("press", v.coerceIn(20L, 300L)).apply()

    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.KOREA)
    private val journal = ArrayDeque<String>()
    @Synchronized fun log(s: String) {
        journal.addFirst("${fmt.format(Date())}  $s")
        while (journal.size > 40) journal.removeLast()
    }
    @Synchronized fun dump(): String = if (journal.isEmpty()) "기록 없음" else journal.joinToString("\n\n")
    @Synchronized fun clearLog() = journal.clear()
}
