package com.example.callassist

/**
 * 실제 우버 콜 카드(2026-11 스크린샷 기준) 구조
 *
 *   [일반 콜 / 가맹 전용 콜 / 호출료 콜]          [X]
 *   39분 운행                      ← 운행 시간(큰 글씨)
 *   11분(2.1km) 남음  (₩3,000의 호출료)  ← 픽업까지 남은 시간(무시)
 *   ● 종로구 화동 삼청로             ← 출발지(무시)
 *   ■ 남동쪽                        ← 방향 줄 = 목적지 시작 표시
 *     서울특별시 강남구 언주로164길   ← 목적지(키워드 검사 대상)
 *   [지도]  [ 콜 수락 ]              ← 수락 버튼(가장 아래)
 *
 * 판독 순서: 수락 버튼을 기준점으로 잡고 → 그 위의 가장 가까운 "N분 운행" → 방향 줄 아래~버튼 위를 목적지로 읽음.
 * 지도 라벨(역 이름 등)이나 위쪽 미니 카드는 위치로 걸러냅니다.
 */
object OfferParser {

    data class Line(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int) {
        val cx get() = (left + right) / 2f
        val cy get() = (top + bottom) / 2f
        val h get() = bottom - top
    }

    data class Result(
        val accept: Boolean,
        val reason: String,
        val tripMinutes: Int? = null,
        val destination: String = "",
        val button: Line? = null,
    )

    private val DUR = Regex("""(\d+)\s*시간(?:\s*(\d+)\s*분)?|(\d+)\s*분""")
    private val DIRECTION = Regex("""^(동|서|남|북|북동|북서|남동|남서)쪽$""")

    fun minutesIn(s: String): Int? {
        val m = DUR.find(s) ?: return null
        return if (m.groupValues[3].isNotEmpty()) m.groupValues[3].toInt()
        else m.groupValues[1].toInt() * 60 + (m.groupValues[2].toIntOrNull() ?: 0)
    }

    private fun compact(s: String) = s.replace(" ", "").trim()

    fun isAcceptLabel(s: String): Boolean {
        val c = compact(s)
        return c == "콜수락" || c == "수락" || c.equals("Accept", true)
    }

    /** "39분 운행", "1시간 5분 운행". "남음"이 붙은 픽업 시간 줄과 "운행 리스트"는 제외 */
    private fun isTripLine(s: String) =
        s.contains("운행") && !s.contains("남음") && !s.contains("리스트") && minutesIn(s) != null

    private fun isDirection(s: String) = DIRECTION.matches(compact(s))

    /**
     * @param lines   화면 좌표계의 텍스트 줄(노드 또는 OCR 결과)
     * @param screenW 같은 좌표계의 화면 너비(지도 가장자리 라벨 제거용)
     */
    fun evaluate(lines: List<Line>, screenW: Int, minMinutes: Int, keywords: List<String>): Result {
        // 1) 수락 버튼: 여러 장이 겹쳐 있으면 가장 아래(맨 앞 카드)
        val button = lines.filter { isAcceptLabel(it.text) }.maxByOrNull { it.bottom }
            ?: return Result(false, "수락 버튼 없음")

        // 2) 카드 안쪽 줄만: 버튼 위, 화면 좌우 가장자리 라벨 제외
        val edgeL = screenW * 0.06f
        val edgeR = screenW * 0.97f
        val card = lines.filter { it !== button && it.bottom <= button.top + button.h / 2 && it.left >= edgeL && it.right <= edgeR }
            .sortedWith(compareBy({ it.top }, { it.left }))

        // 3) 운행 시간: 버튼에 가장 가까운(아래쪽) 운행 줄. "39분" 과 "운행"이 따로 읽힌 경우도 처리
        var trip = card.filter { isTripLine(it.text) }.maxByOrNull { it.top }
        if (trip == null) {
            val word = card.filter { compact(it.text) == "운행" }.maxByOrNull { it.top }
            if (word != null) trip = card.filter {
                it !== word && minutesIn(it.text) != null && !it.text.contains("남음") &&
                    kotlin.math.abs(it.cy - word.cy) < word.h
            }.maxByOrNull { it.top }
        }
        if (trip == null) return Result(false, "운행 시간 미확인", button = button)
        val minutes = minutesIn(trip.text)!!

        // 4) 목적지: 운행 줄 아래 ~ 버튼 위 중에서 방향 줄(북동쪽 등) 다음 줄들
        val body = card.filter { it.top > trip.bottom - trip.h / 4 }
        val dirIdx = body.indexOfLast { isDirection(it.text) }
        if (dirIdx < 0) return Result(false, "목적지 구분 실패(방향 줄 없음)", minutes, button = button)
        val dest = body.drop(dirIdx + 1).joinToString(" ") { it.text.trim() }
        val destC = compact(dest)
        val hit = keywords.map { compact(it) }.filter { it.isNotEmpty() }.firstOrNull { destC.contains(it) }

        return when {
            minutes < minMinutes -> Result(false, "운행 ${minutes}분 < ${minMinutes}분", minutes, dest, button)
            hit == null -> Result(false, "목적지 키워드 없음", minutes, dest, button)
            else -> Result(true, "운행 ${minutes}분 · 목적지 '$hit'", minutes, dest, button)
        }
    }
}
