package com.example.callassist

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var minEt: EditText
    private lateinit var kwEt: EditText
    private lateinit var roiEt: EditText
    private lateinit var pressEt: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun field(parent: LinearLayout, label: String, value: String, number: Boolean): EditText {
        parent.addView(TextView(this).apply { text = label; setPadding(0, dp(12), 0, 0) })
        val et = EditText(this).apply {
            setText(value); setSingleLine()
            if (number) inputType = InputType.TYPE_CLASS_NUMBER
        }
        parent.addView(et); return et
    }

    private fun button(parent: LinearLayout, label: String, onClick: () -> Unit): Button {
        val b = Button(this).apply { text = label; setOnClickListener { onClick() } }
        parent.addView(b, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return b
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)) }
        setContentView(ScrollView(this).apply { addView(col) })

        status = TextView(this).apply { textSize = 16f }
        col.addView(status)
        button(col, "접근성 설정 열기") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }

        minEt = field(col, "최소 운행시간(분)", Store.minMinutes.toString(), true)
        kwEt = field(col, "목적지 키워드(쉼표 구분)", Store.keywords, false)
        roiEt = field(col, "OCR 제외 상단 비율(%) - 클수록 빠름", Store.roiTopPct.toString(), true)
        pressEt = field(col, "누름 시간(ms)", Store.pressMs.toString(), true)

        toggle = button(col, "시작") { onToggle() }
        button(col, "입력별 기록 보기") {
            AlertDialog.Builder(this).setTitle("기록(최근 40건)").setMessage(Store.dump())
                .setPositiveButton("닫기", null).setNegativeButton("지우기") { _, _ -> Store.clearLog() }.show()
        }
        col.addView(TextView(this).apply {
            setPadding(0, dp(16), 0, 0)
            text = "※ 수락 1회 입력 후 자동으로 중지됩니다. 다음 콜은 '시작'을 다시 누르세요.\n" +
                   "※ '응답=완료'는 Android가 제스처를 수행했다는 뜻이며 우버의 배차 성공을 보장하지 않습니다."
        })
    }

    private fun save() {
        Store.minMinutes = minEt.text.toString().toIntOrNull() ?: 40
        Store.keywords = kwEt.text.toString()
        Store.roiTopPct = roiEt.text.toString().toIntOrNull() ?: 35
        Store.pressMs = pressEt.text.toString().toLongOrNull() ?: 60L
    }

    private fun onToggle() {
        save()
        if (AutoAcceptService.instance == null) { refresh("접근성 서비스가 꺼져 있습니다. 먼저 설정에서 켜 주세요."); return }
        Store.armed = !Store.armed
        refresh(null)
    }

    private fun refresh(msg: String?) {
        val svc = AutoAcceptService.instance != null
        status.text = msg ?: "접근성 서비스: ${if (svc) "켜짐" else "꺼짐"}\n상태: ${if (Store.armed) "대기 중(콜 감시)" else "중지"}"
        toggle.text = if (Store.armed) "중지" else "시작"
    }

    override fun onResume() { super.onResume(); refresh(null) }
}
