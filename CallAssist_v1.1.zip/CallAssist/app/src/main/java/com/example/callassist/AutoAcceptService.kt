package com.example.callassist

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import com.example.callassist.OfferParser.Line
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * 속도: ① 접근성 노드에서 먼저 읽기(OCR 없음) ② 안 되면 화면 아래쪽만 잘라 축소 후 OCR, 인식기 재사용, 처리 중 프레임 폐기
 * 클릭: ① 노드 ACTION_CLICK ② 안 되면 좌표 제스처(자르기·축소 역변환)
 * 떠 있는 카드: 우버 콜 카드가 다른 앱(카톡 등) 위에 팝업으로 뜨는 경우가 있어
 *   '맨 앞 앱이 우버인가'가 아니라 '우버 창 중 버튼 위치를 덮는 다른 창이 없는가'로 확인합니다.
 */
class AutoAcceptService : AccessibilityService() {

    companion object {
        const val TARGET = "com.ubercab.driver"
        @Volatile var instance: AutoAcceptService? = null
        private const val MIN_GAP_MS = 100L
        private const val OCR_GAP_MS = 450L        // 시스템 스크린샷 최소 간격(약 333ms)보다 약간 크게
        private const val POLL_MS = 600L
        private const val MAX_W = 720f
        private const val MAX_FRAME_AGE_MS = 1500L
    }

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val recognizer by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val busy = AtomicBoolean(false)
    @Volatile private var pending = false
    private var lastRun = 0L
    private var lastOcr = 0L
    private var lastRejectNote = ""

    private val poll = object : Runnable {
        override fun run() {
            if (Store.armed) analyze()
            main.postDelayed(this, POLL_MS)
        }
    }

    override fun onServiceConnected() {
        Store.init(this)
        instance = this
        Store.armed = false
        recognizer // 미리 생성(첫 인식 지연 방지)
        main.postDelayed(poll, POLL_MS)
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null; main.removeCallbacks(poll); Store.armed = false
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (Store.armed) analyze()
    }

    private val screenW get() = resources.displayMetrics.widthPixels
    private fun kw() = Store.keywords.split(",")

    // ------------------------------------------------------------------ 분석
    private fun analyze() {
        if (!Store.armed) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastRun < MIN_GAP_MS) { pending = true; return }
        if (!busy.compareAndSet(false, true)) { pending = true; return }
        lastRun = now; pending = false
        try {
            if (!nativePath(now)) ocrPath(now) else finish()
        } catch (t: Throwable) {
            Store.log("오류(분석): ${t.javaClass.simpleName}"); finish()
        }
    }

    private fun finish() {
        busy.set(false)
        if (pending && Store.armed) main.postDelayed({ analyze() }, MIN_GAP_MS)
    }

    /** 같은 거절 사유가 반복 기록되지 않게 */
    private fun noteReject(r: OfferParser.Result) {
        val key = "${r.tripMinutes}|${r.destination}|${r.reason}"
        if (key != lastRejectNote) { lastRejectNote = key; Store.log("통과 안 함: ${r.reason}${r.tripMinutes?.let { " (${it}분)" } ?: ""}") }
    }

    // ------------------------------------------------------------ 창 확인
    private fun uberWindows(): List<AccessibilityWindowInfo> =
        windows.filter { it.root?.packageName?.toString() == TARGET }

    /** (x,y)에 탭하면 우버 창이 받는지: 우버 창 안이고, 그 위에 덮는 다른 앱 창이 없어야 함 */
    private fun uberOwnsPoint(x: Int, y: Int): Boolean {
        val all = windows
        val r = Rect()
        val uber = all.filter { it.root?.packageName?.toString() == TARGET }
            .filter { it.getBoundsInScreen(r); r.contains(x, y) }
            .maxByOrNull { it.layer } ?: return false
        return all.none { w ->
            w.layer > uber.layer && w.type != AccessibilityWindowInfo.TYPE_ACCESSIBILITY_OVERLAY &&
                w.root?.packageName?.toString() != TARGET &&
                run { w.getBoundsInScreen(r); r.contains(x, y) }
        }
    }

    // ------------------------------------------------------------ 1) 노드 경로
    private class NodeLine(val line: Line, val node: AccessibilityNodeInfo)

    private fun collect(n: AccessibilityNodeInfo?, out: MutableList<NodeLine>, depth: Int = 0) {
        if (n == null || depth > 45 || !n.isVisibleToUser) return
        val t = (n.text ?: n.contentDescription)?.toString()?.trim()
        if (!t.isNullOrEmpty()) {
            val r = Rect(); n.getBoundsInScreen(r)
            out.add(NodeLine(Line(t, r.left, r.top, r.right, r.bottom), n))
        }
        for (i in 0 until n.childCount) collect(n.getChild(i), out, depth + 1)
    }

    /** @return true = 노드로 판단 완료, false = OCR 필요 */
    private fun nativePath(t0: Long): Boolean {
        val wins = uberWindows()
        if (wins.isEmpty()) return true                       // 우버 창 자체가 없으면 OCR도 하지 않음
        val nodes = ArrayList<NodeLine>()
        wins.forEach { collect(it.root, nodes) }
        if (nodes.none { OfferParser.isAcceptLabel(it.line.text) }) return false
        val res = OfferParser.evaluate(nodes.map { it.line }, screenW, Store.minMinutes, kw())
        if (res.tripMinutes == null) return false             // 카드 글자를 노드로 못 읽음 → OCR
        val ms = SystemClock.elapsedRealtime() - t0
        if (!res.accept) { noteReject(res); return true }
        val btn = nodes.first { it.line === res.button }
        Store.armed = false
        if (clickNode(btn.node)) {
            Store.log("노드 클릭 | ${res.reason} | 분석 ${ms}ms")
        } else {
            tap(btn.line.cx, btn.line.cy, "노드→제스처", res.reason, ms)
        }
        return true
    }

    private fun clickNode(start: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = start
        repeat(4) {
            val n = cur ?: return false
            if (n.isClickable && n.isEnabled) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            cur = n.parent
        }
        return false
    }

    // ------------------------------------------------------------- 2) OCR 경로
    private fun ocrPath(t0: Long) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastOcr < OCR_GAP_MS) { pending = true; finish(); return }
        lastOcr = now
        takeScreenshot(Display.DEFAULT_DISPLAY, worker, object : TakeScreenshotCallback {
            override fun onSuccess(shot: ScreenshotResult) {
                try {
                    val hw = shot.hardwareBuffer
                    val hwBmp = Bitmap.wrapHardwareBuffer(hw, shot.colorSpace)
                    if (hwBmp == null) { hw.close(); finish(); return }
                    val W = hwBmp.width; val H = hwBmp.height
                    val top = H * Store.roiTopPct / 100
                    val scale = minOf(1f, MAX_W / W)
                    val dw = (W * scale).toInt().coerceAtLeast(1)
                    val dh = ((H - top) * scale).toInt().coerceAtLeast(1)
                    // 하드웨어 비트맵 → 잘라서 축소한 소프트 비트맵 (전체 복사 없이 한 번에)
                    val soft = hwBmp.copy(Bitmap.Config.ARGB_8888, false)
                    hwBmp.recycle(); hw.close()
                    val small = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888)
                    Canvas(small).drawBitmap(soft, Rect(0, top, W, H), Rect(0, 0, dw, dh), Paint(Paint.FILTER_BITMAP_FLAG))
                    soft.recycle()
                    val shotMs = SystemClock.elapsedRealtime() - t0
                    recognizer.process(InputImage.fromBitmap(small, 0))
                        .addOnSuccessListener(worker) { text ->
                            small.recycle()
                            try { onOcr(text, scale, top, W, t0, shotMs) } finally { finish() }
                        }
                        .addOnFailureListener(worker) { small.recycle(); Store.log("OCR 실패"); finish() }
                } catch (t: Throwable) {
                    Store.log("오류(캡처): ${t.javaClass.simpleName}"); finish()
                }
            }
            override fun onFailure(code: Int) {
                if (code != AccessibilityService.ERROR_TAKE_SCREENSHOT_INTERVAL_TIME_SHORT) Store.log("캡처 오류 코드=$code")
                else pending = true
                finish()
            }
        })
    }

    private fun onOcr(text: com.google.mlkit.vision.text.Text, scale: Float, top: Int, fullW: Int, t0: Long, shotMs: Long) {
        if (!Store.armed) return
        // OCR 좌표 → 실제 화면 좌표로 되돌림
        val lines = text.textBlocks.flatMap { it.lines }.mapNotNull { l ->
            l.boundingBox?.let { b ->
                Line(l.text, (b.left / scale).toInt(), (b.top / scale).toInt() + top,
                    (b.right / scale).toInt(), (b.bottom / scale).toInt() + top)
            }
        }
        val res = OfferParser.evaluate(lines, fullW, Store.minMinutes, kw())
        if (res.button == null) return
        if (!res.accept) { noteReject(res); return }
        val total = SystemClock.elapsedRealtime() - t0
        if (total > MAX_FRAME_AGE_MS) { Store.log("화면이 오래되어 탭 취소(${total}ms)"); return }
        val b = res.button
        main.post {
            if (!Store.armed) return@post
            Store.armed = false
            tap(b.cx, b.cy, "OCR(캡처 ${shotMs}ms)", res.reason, total)
        }
    }

    // --------------------------------------------------------------- 제스처
    private fun tap(x: Float, y: Float, via: String, reason: String, analyzeMs: Long) {
        if (!uberOwnsPoint(x.toInt(), y.toInt())) {
            Store.log("$via | 탭 취소: 버튼 위치에 우버 창이 없거나 다른 창이 덮고 있음 (${x.toInt()},${y.toInt()})")
            return
        }
        val press = Store.pressMs
        val sentAt = SystemClock.elapsedRealtime()
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(Path().apply { moveTo(x, y) }, 0, press)).build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) {
                Store.log("$via | $reason | 분석 ${analyzeMs}ms | (${x.toInt()},${y.toInt()}) ${press}ms | 응답=완료 +${SystemClock.elapsedRealtime() - sentAt}ms")
            }
            override fun onCancelled(d: GestureDescription?) {
                Store.log("$via | (${x.toInt()},${y.toInt()}) | 응답=취소됨(다른 터치/화면 변경)")
            }
        }, main)
        if (!ok) Store.log("$via | 제스처 요청 거절됨(접근성 권한 확인)")
    }
}
